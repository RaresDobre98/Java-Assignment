package com.fulfilment.application.monolith.fulfilment.domain.ports;

import com.fulfilment.application.monolith.fulfilment.domain.models.FulfilmentAssignment;

public interface AssignFulfilmentUnitOperation {

  void assign(FulfilmentAssignment assignment);
}
