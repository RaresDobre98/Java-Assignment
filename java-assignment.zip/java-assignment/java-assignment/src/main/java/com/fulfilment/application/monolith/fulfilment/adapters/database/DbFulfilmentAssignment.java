package com.fulfilment.application.monolith.fulfilment.adapters.database;

import com.fulfilment.application.monolith.fulfilment.domain.models.FulfilmentAssignment;
import jakarta.persistence.Cacheable;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDateTime;

@Entity
@Table(
    name = "fulfilment_assignment",
    uniqueConstraints =
        @UniqueConstraint(
            columnNames = {"store_id", "product_id", "warehouse_business_unit_code"}))
@Cacheable
public class DbFulfilmentAssignment {

  @Id @GeneratedValue public Long id;

  @Column(name = "store_id", nullable = false)
  public Long storeId;

  @Column(name = "product_id", nullable = false)
  public Long productId;

  @Column(name = "warehouse_business_unit_code", nullable = false)
  public String warehouseBusinessUnitCode;

  public LocalDateTime createdAt;

  public FulfilmentAssignment toDomain() {
    var assignment = new FulfilmentAssignment();
    assignment.storeId = storeId;
    assignment.productId = productId;
    assignment.warehouseBusinessUnitCode = warehouseBusinessUnitCode;
    assignment.createdAt = createdAt;
    return assignment;
  }

  public static DbFulfilmentAssignment from(FulfilmentAssignment assignment) {
    var entity = new DbFulfilmentAssignment();
    entity.storeId = assignment.storeId;
    entity.productId = assignment.productId;
    entity.warehouseBusinessUnitCode = assignment.warehouseBusinessUnitCode;
    entity.createdAt = assignment.createdAt;
    return entity;
  }
}
