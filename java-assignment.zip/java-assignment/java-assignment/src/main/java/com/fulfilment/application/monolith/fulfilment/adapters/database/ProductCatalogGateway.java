package com.fulfilment.application.monolith.fulfilment.adapters.database;

import com.fulfilment.application.monolith.fulfilment.domain.ports.ProductCatalog;
import com.fulfilment.application.monolith.products.ProductRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

@ApplicationScoped
public class ProductCatalogGateway implements ProductCatalog {

  @Inject ProductRepository productRepository;

  @Override
  public boolean exists(Long productId) {
    return productId != null && productRepository.findById(productId) != null;
  }
}
