package com.fulfilment.application.monolith.fulfilment.domain.ports;

import com.fulfilment.application.monolith.fulfilment.domain.models.FulfilmentAssignment;
import java.util.List;

public interface FulfilmentAssignmentStore {

  List<FulfilmentAssignment> getAll();

  void create(FulfilmentAssignment assignment);

  boolean exists(Long storeId, Long productId, String warehouseBusinessUnitCode);

  long countWarehousesForProductAtStore(Long storeId, Long productId);

  long countWarehousesForStore(Long storeId);

  long countProductsForWarehouse(String warehouseBusinessUnitCode);
}
