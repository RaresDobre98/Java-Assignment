package com.fulfilment.application.monolith.fulfilment.domain.ports;

public interface ProductCatalog {

  boolean exists(Long productId);
}
