package com.fulfilment.application.monolith.fulfilment.domain.usecases;

import com.fulfilment.application.monolith.fulfilment.domain.models.FulfilmentAssignment;
import com.fulfilment.application.monolith.fulfilment.domain.ports.AssignFulfilmentUnitOperation;
import com.fulfilment.application.monolith.fulfilment.domain.ports.FulfilmentAssignmentStore;
import com.fulfilment.application.monolith.fulfilment.domain.ports.ProductCatalog;
import com.fulfilment.application.monolith.fulfilment.domain.ports.StoreCatalog;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;
import java.time.LocalDateTime;

@ApplicationScoped
public class AssignFulfilmentUnitUseCase implements AssignFulfilmentUnitOperation {

  private final FulfilmentAssignmentStore assignmentStore;
  private final StoreCatalog storeCatalog;
  private final ProductCatalog productCatalog;
  private final WarehouseStore warehouseStore;

  public AssignFulfilmentUnitUseCase(
      FulfilmentAssignmentStore assignmentStore,
      StoreCatalog storeCatalog,
      ProductCatalog productCatalog,
      WarehouseStore warehouseStore) {
    this.assignmentStore = assignmentStore;
    this.storeCatalog = storeCatalog;
    this.productCatalog = productCatalog;
    this.warehouseStore = warehouseStore;
  }

  @Override
  public void assign(FulfilmentAssignment assignment) {
    validateRequiredFields(assignment);
    validateReferencedEntities(assignment);

    if (assignmentStore.exists(
        assignment.storeId, assignment.productId, assignment.warehouseBusinessUnitCode)) {
      return;
    }

    if (assignmentStore.countWarehousesForProductAtStore(assignment.storeId, assignment.productId) >= 2) {
      throw new WebApplicationException(
          "A product can be fulfilled by a maximum of 2 warehouses per store.", 400);
    }

    if (!warehouseAlreadyFulfilsStore(assignment)
        && assignmentStore.countWarehousesForStore(assignment.storeId) >= 3) {
      throw new WebApplicationException(
          "A store can be fulfilled by a maximum of 3 different warehouses.", 400);
    }

    if (!productAlreadyStoredInWarehouse(assignment)
        && assignmentStore.countProductsForWarehouse(assignment.warehouseBusinessUnitCode) >= 5) {
      throw new WebApplicationException(
          "A warehouse can store a maximum of 5 different product types.", 400);
    }

    assignment.createdAt = LocalDateTime.now();
    assignmentStore.create(assignment);
  }

  private boolean warehouseAlreadyFulfilsStore(FulfilmentAssignment assignment) {
    return assignmentStore.getAll().stream()
        .anyMatch(
            existing ->
                assignment.storeId.equals(existing.storeId)
                    && assignment.warehouseBusinessUnitCode.equals(existing.warehouseBusinessUnitCode));
  }

  private boolean productAlreadyStoredInWarehouse(FulfilmentAssignment assignment) {
    return assignmentStore.getAll().stream()
        .anyMatch(
            existing ->
                assignment.productId.equals(existing.productId)
                    && assignment.warehouseBusinessUnitCode.equals(existing.warehouseBusinessUnitCode));
  }

  private void validateRequiredFields(FulfilmentAssignment assignment) {
    if (assignment == null) {
      throw new WebApplicationException("Fulfilment assignment request body is required.", 400);
    }
    if (assignment.storeId == null) {
      throw new WebApplicationException("Store id was not set on request.", 400);
    }
    if (assignment.productId == null) {
      throw new WebApplicationException("Product id was not set on request.", 400);
    }
    if (assignment.warehouseBusinessUnitCode == null
        || assignment.warehouseBusinessUnitCode.isBlank()) {
      throw new WebApplicationException("Warehouse Business Unit Code was not set on request.", 400);
    }
  }

  private void validateReferencedEntities(FulfilmentAssignment assignment) {
    if (!storeCatalog.exists(assignment.storeId)) {
      throw new WebApplicationException(
          "Store with id of " + assignment.storeId + " does not exist.", 404);
    }
    if (!productCatalog.exists(assignment.productId)) {
      throw new WebApplicationException(
          "Product with id of " + assignment.productId + " does not exist.", 404);
    }
    if (warehouseStore.findByBusinessUnitCode(assignment.warehouseBusinessUnitCode) == null) {
      throw new WebApplicationException(
          "Warehouse with businessUnitCode of "
              + assignment.warehouseBusinessUnitCode
              + " does not exist.",
          404);
    }
  }
}
