package com.fulfilment.application.monolith.warehouses.adapters.database;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;
import java.time.LocalDateTime;
import java.util.List;

@ApplicationScoped
public class WarehouseRepository implements WarehouseStore, PanacheRepository<DbWarehouse> {

  @Override
  public List<Warehouse> getAll() {
    return this.list("archivedAt is null").stream().map(DbWarehouse::toWarehouse).toList();
  }

  @Override
  public void create(Warehouse warehouse) {
    DbWarehouse dbWarehouse = toDbWarehouse(warehouse);
    dbWarehouse.createdAt = dbWarehouse.createdAt == null ? LocalDateTime.now() : dbWarehouse.createdAt;
    persist(dbWarehouse);
  }

  @Override
  public void update(Warehouse warehouse) {
    DbWarehouse entity = findActiveEntityByBusinessUnitCode(warehouse.businessUnitCode);
    if (entity == null) {
      throw new WebApplicationException(
          "Warehouse with businessUnitCode of " + warehouse.businessUnitCode + " does not exist.", 404);
    }

    entity.location = warehouse.location;
    entity.capacity = warehouse.capacity;
    entity.stock = warehouse.stock;
    entity.archivedAt = warehouse.archivedAt;
  }

  @Override
  public void remove(Warehouse warehouse) {
    DbWarehouse entity = findActiveEntityByBusinessUnitCode(warehouse.businessUnitCode);
    if (entity == null) {
      throw new WebApplicationException(
          "Warehouse with businessUnitCode of " + warehouse.businessUnitCode + " does not exist.", 404);
    }
    delete(entity);
  }

  @Override
  public Warehouse findByBusinessUnitCode(String buCode) {
    DbWarehouse entity = findActiveEntityByBusinessUnitCode(buCode);
    return entity == null ? null : entity.toWarehouse();
  }

  public Warehouse findActiveById(Long id) {
    DbWarehouse entity = find("id = ?1 and archivedAt is null", id).firstResult();
    return entity == null ? null : entity.toWarehouse();
  }

  public Warehouse findActiveByIdentifier(String identifier) {
    try {
      return findActiveById(Long.valueOf(identifier));
    } catch (NumberFormatException ignored) {
      return findByBusinessUnitCode(identifier);
    }
  }

  public long countActiveByLocation(String location) {
    return count("location = ?1 and archivedAt is null", location);
  }

  public int sumActiveCapacityByLocation(String location) {
    return getEntityManager()
        .createQuery(
            "select coalesce(sum(w.capacity), 0) from DbWarehouse w where w.location = :location and w.archivedAt is null",
            Number.class)
        .setParameter("location", location)
        .getSingleResult()
        .intValue();
  }

  private DbWarehouse findActiveEntityByBusinessUnitCode(String businessUnitCode) {
    return find("businessUnitCode = ?1 and archivedAt is null", businessUnitCode).firstResult();
  }

  private DbWarehouse toDbWarehouse(Warehouse warehouse) {
    var entity = new DbWarehouse();
    entity.businessUnitCode = warehouse.businessUnitCode;
    entity.location = warehouse.location;
    entity.capacity = warehouse.capacity;
    entity.stock = warehouse.stock;
    entity.createdAt = warehouse.createdAt;
    entity.archivedAt = warehouse.archivedAt;
    return entity;
  }
}
