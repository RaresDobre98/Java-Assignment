package com.fulfilment.application.monolith.fulfilment.adapters.database;

import com.fulfilment.application.monolith.fulfilment.domain.models.FulfilmentAssignment;
import com.fulfilment.application.monolith.fulfilment.domain.ports.FulfilmentAssignmentStore;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class FulfilmentAssignmentRepository
    implements FulfilmentAssignmentStore, PanacheRepository<DbFulfilmentAssignment> {

  @Override
  public List<FulfilmentAssignment> getAll() {
    return listAll().stream().map(DbFulfilmentAssignment::toDomain).toList();
  }

  @Override
  public void create(FulfilmentAssignment assignment) {
    persist(DbFulfilmentAssignment.from(assignment));
  }

  @Override
  public boolean exists(Long storeId, Long productId, String warehouseBusinessUnitCode) {
    return count(
            "storeId = ?1 and productId = ?2 and warehouseBusinessUnitCode = ?3",
            storeId,
            productId,
            warehouseBusinessUnitCode)
        > 0;
  }

  @Override
  public long countWarehousesForProductAtStore(Long storeId, Long productId) {
    return getEntityManager()
        .createQuery(
            "select count(distinct a.warehouseBusinessUnitCode) "
                + "from DbFulfilmentAssignment a "
                + "where a.storeId = :storeId and a.productId = :productId",
            Long.class)
        .setParameter("storeId", storeId)
        .setParameter("productId", productId)
        .getSingleResult();
  }

  @Override
  public long countWarehousesForStore(Long storeId) {
    return getEntityManager()
        .createQuery(
            "select count(distinct a.warehouseBusinessUnitCode) "
                + "from DbFulfilmentAssignment a "
                + "where a.storeId = :storeId",
            Long.class)
        .setParameter("storeId", storeId)
        .getSingleResult();
  }

  @Override
  public long countProductsForWarehouse(String warehouseBusinessUnitCode) {
    return getEntityManager()
        .createQuery(
            "select count(distinct a.productId) "
                + "from DbFulfilmentAssignment a "
                + "where a.warehouseBusinessUnitCode = :warehouseBusinessUnitCode",
            Long.class)
        .setParameter("warehouseBusinessUnitCode", warehouseBusinessUnitCode)
        .getSingleResult();
  }
}
