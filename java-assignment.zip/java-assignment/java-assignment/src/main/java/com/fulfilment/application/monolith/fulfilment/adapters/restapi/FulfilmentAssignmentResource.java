package com.fulfilment.application.monolith.fulfilment.adapters.restapi;

import com.fulfilment.application.monolith.fulfilment.domain.models.FulfilmentAssignment;
import com.fulfilment.application.monolith.fulfilment.domain.ports.AssignFulfilmentUnitOperation;
import com.fulfilment.application.monolith.fulfilment.domain.ports.FulfilmentAssignmentStore;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("fulfilment-assignments")
@ApplicationScoped
@Produces("application/json")
@Consumes("application/json")
public class FulfilmentAssignmentResource {

  @Inject AssignFulfilmentUnitOperation assignFulfilmentUnitOperation;

  @Inject FulfilmentAssignmentStore fulfilmentAssignmentStore;

  @GET
  public List<FulfilmentAssignmentResponse> get() {
    return fulfilmentAssignmentStore.getAll().stream().map(FulfilmentAssignmentResponse::from).toList();
  }

  @POST
  @Transactional
  public Response assign(FulfilmentAssignmentRequest request) {
    FulfilmentAssignment assignment = request.toDomain();

    assignFulfilmentUnitOperation.assign(assignment);

    return Response.status(201).entity(FulfilmentAssignmentResponse.from(assignment)).build();
  }

  public static class FulfilmentAssignmentRequest {
    public Long storeId;
    public Long productId;
    public String warehouseBusinessUnitCode;

    FulfilmentAssignment toDomain() {
      var assignment = new FulfilmentAssignment();
      assignment.storeId = storeId;
      assignment.productId = productId;
      assignment.warehouseBusinessUnitCode = warehouseBusinessUnitCode;
      return assignment;
    }
  }

  public static class FulfilmentAssignmentResponse {
    public Long storeId;
    public Long productId;
    public String warehouseBusinessUnitCode;

    static FulfilmentAssignmentResponse from(FulfilmentAssignment assignment) {
      var response = new FulfilmentAssignmentResponse();
      response.storeId = assignment.storeId;
      response.productId = assignment.productId;
      response.warehouseBusinessUnitCode = assignment.warehouseBusinessUnitCode;
      return response;
    }
  }
}
