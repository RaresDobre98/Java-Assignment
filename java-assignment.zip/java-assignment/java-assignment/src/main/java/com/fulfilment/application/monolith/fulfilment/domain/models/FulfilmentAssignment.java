package com.fulfilment.application.monolith.fulfilment.domain.models;

import java.time.LocalDateTime;

public class FulfilmentAssignment {

  public Long storeId;

  public Long productId;

  public String warehouseBusinessUnitCode;

  public LocalDateTime createdAt;
}
