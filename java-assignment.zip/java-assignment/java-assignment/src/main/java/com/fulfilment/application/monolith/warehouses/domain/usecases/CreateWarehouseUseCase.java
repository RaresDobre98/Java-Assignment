package com.fulfilment.application.monolith.warehouses.domain.usecases;

import com.fulfilment.application.monolith.warehouses.domain.models.Location;
import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.CreateWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.LocationResolver;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;

@ApplicationScoped
public class CreateWarehouseUseCase implements CreateWarehouseOperation {

  private final WarehouseStore warehouseStore;
  private final LocationResolver locationResolver;

  public CreateWarehouseUseCase(WarehouseStore warehouseStore, LocationResolver locationResolver) {
    this.warehouseStore = warehouseStore;
    this.locationResolver = locationResolver;
  }

  @Override
  public void create(Warehouse warehouse) {
    validateRequiredFields(warehouse);

    if (warehouseStore.findByBusinessUnitCode(warehouse.businessUnitCode) != null) {
      throw new WebApplicationException(
          "Warehouse with businessUnitCode of " + warehouse.businessUnitCode + " already exists.", 400);
    }

    Location location = resolveValidLocation(warehouse.location);
    validateCapacityAndStock(warehouse, location);
    validateLocationAvailability(warehouse, location);

    warehouseStore.create(warehouse);
  }

  private void validateRequiredFields(Warehouse warehouse) {
    if (warehouse == null) {
      throw new WebApplicationException("Warehouse request body is required.", 400);
    }
    if (warehouse.businessUnitCode == null || warehouse.businessUnitCode.isBlank()) {
      throw new WebApplicationException("Business Unit Code was not set on request.", 400);
    }
    if (warehouse.location == null || warehouse.location.isBlank()) {
      throw new WebApplicationException("Warehouse location was not set on request.", 400);
    }
    if (warehouse.capacity == null || warehouse.capacity <= 0) {
      throw new WebApplicationException("Warehouse capacity must be greater than zero.", 400);
    }
    if (warehouse.stock == null || warehouse.stock < 0) {
      throw new WebApplicationException("Warehouse stock cannot be negative.", 400);
    }
  }

  private Location resolveValidLocation(String locationIdentifier) {
    Location location = locationResolver.resolveByIdentifier(locationIdentifier);
    if (location == null) {
      throw new WebApplicationException(
          "Location with identifier of " + locationIdentifier + " does not exist.", 400);
    }
    return location;
  }

  private void validateCapacityAndStock(Warehouse warehouse, Location location) {
    if (warehouse.capacity > location.maxCapacity) {
      throw new WebApplicationException(
          "Warehouse capacity exceeds location maximum capacity of " + location.maxCapacity + ".", 400);
    }
    if (warehouse.stock > warehouse.capacity) {
      throw new WebApplicationException("Warehouse capacity cannot accommodate informed stock.", 400);
    }
  }

  private void validateLocationAvailability(Warehouse warehouse, Location location) {
    long warehousesAtLocation =
        warehouseStore.getAll().stream()
            .filter(activeWarehouse -> warehouse.location.equals(activeWarehouse.location))
            .count();

    if (warehousesAtLocation >= location.maxNumberOfWarehouses) {
      throw new WebApplicationException(
          "Location " + warehouse.location + " has reached the maximum number of warehouses.", 400);
    }

    int usedCapacityAtLocation =
        warehouseStore.getAll().stream()
            .filter(activeWarehouse -> warehouse.location.equals(activeWarehouse.location))
            .mapToInt(activeWarehouse -> activeWarehouse.capacity == null ? 0 : activeWarehouse.capacity)
            .sum();

    if (usedCapacityAtLocation + warehouse.capacity > location.maxCapacity) {
      throw new WebApplicationException(
          "Warehouse capacity exceeds remaining capacity for location " + warehouse.location + ".", 400);
    }
  }
}
