package com.fulfilment.application.monolith.warehouses.domain.usecases;

import com.fulfilment.application.monolith.warehouses.domain.models.Location;
import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.LocationResolver;
import com.fulfilment.application.monolith.warehouses.domain.ports.ReplaceWarehouseOperation;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.WebApplicationException;
import java.time.LocalDateTime;

@ApplicationScoped
public class ReplaceWarehouseUseCase implements ReplaceWarehouseOperation {

  private final WarehouseStore warehouseStore;
  private final LocationResolver locationResolver;

  public ReplaceWarehouseUseCase(WarehouseStore warehouseStore, LocationResolver locationResolver) {
    this.warehouseStore = warehouseStore;
    this.locationResolver = locationResolver;
  }

  @Override
  public void replace(Warehouse newWarehouse) {
    validateRequiredFields(newWarehouse);

    Warehouse currentWarehouse = warehouseStore.findByBusinessUnitCode(newWarehouse.businessUnitCode);
    if (currentWarehouse == null) {
      throw new WebApplicationException(
          "Warehouse with businessUnitCode of " + newWarehouse.businessUnitCode + " does not exist.", 404);
    }

    if (!newWarehouse.stock.equals(currentWarehouse.stock)) {
      throw new WebApplicationException(
          "Replacement warehouse stock must match the current warehouse stock.", 400);
    }

    if (newWarehouse.capacity < currentWarehouse.stock) {
      throw new WebApplicationException(
          "Replacement warehouse capacity cannot accommodate current warehouse stock.", 400);
    }

    Location location = resolveValidLocation(newWarehouse.location);
    validateCapacityAndStock(newWarehouse, location);
    validateLocationAvailabilityForReplacement(newWarehouse, currentWarehouse, location);

    currentWarehouse.archivedAt = LocalDateTime.now();
    warehouseStore.update(currentWarehouse);

    newWarehouse.createdAt = LocalDateTime.now();
    newWarehouse.archivedAt = null;
    warehouseStore.create(newWarehouse);
  }

  private void validateRequiredFields(Warehouse warehouse) {
    if (warehouse == null) {
      throw new WebApplicationException("Warehouse request body is required.", 400);
    }
    if (warehouse.businessUnitCode == null || warehouse.businessUnitCode.isBlank()) {
      throw new WebApplicationException("Business Unit Code was not set on request.", 400);
    }
    if (warehouse.location == null || warehouse.location.isBlank()) {
      throw new WebApplicationException("Warehouse location was not set on request.", 400);
    }
    if (warehouse.capacity == null || warehouse.capacity <= 0) {
      throw new WebApplicationException("Warehouse capacity must be greater than zero.", 400);
    }
    if (warehouse.stock == null || warehouse.stock < 0) {
      throw new WebApplicationException("Warehouse stock cannot be negative.", 400);
    }
  }

  private Location resolveValidLocation(String locationIdentifier) {
    Location location = locationResolver.resolveByIdentifier(locationIdentifier);
    if (location == null) {
      throw new WebApplicationException(
          "Location with identifier of " + locationIdentifier + " does not exist.", 400);
    }
    return location;
  }

  private void validateCapacityAndStock(Warehouse warehouse, Location location) {
    if (warehouse.capacity > location.maxCapacity) {
      throw new WebApplicationException(
          "Warehouse capacity exceeds location maximum capacity of " + location.maxCapacity + ".", 400);
    }
    if (warehouse.stock > warehouse.capacity) {
      throw new WebApplicationException("Warehouse capacity cannot accommodate informed stock.", 400);
    }
  }

  private void validateLocationAvailabilityForReplacement(
      Warehouse newWarehouse, Warehouse currentWarehouse, Location location) {
    long activeWarehousesAtLocationAfterReplacement =
        warehouseStore.getAll().stream()
            .filter(activeWarehouse -> newWarehouse.location.equals(activeWarehouse.location))
            .filter(
                activeWarehouse ->
                    !activeWarehouse.businessUnitCode.equals(currentWarehouse.businessUnitCode))
            .count();

    if (activeWarehousesAtLocationAfterReplacement >= location.maxNumberOfWarehouses) {
      throw new WebApplicationException(
          "Location " + newWarehouse.location + " has reached the maximum number of warehouses.", 400);
    }

    int usedCapacityAtLocationAfterReplacement =
        warehouseStore.getAll().stream()
            .filter(activeWarehouse -> newWarehouse.location.equals(activeWarehouse.location))
            .filter(
                activeWarehouse ->
                    !activeWarehouse.businessUnitCode.equals(currentWarehouse.businessUnitCode))
            .mapToInt(activeWarehouse -> activeWarehouse.capacity == null ? 0 : activeWarehouse.capacity)
            .sum();

    if (usedCapacityAtLocationAfterReplacement + newWarehouse.capacity > location.maxCapacity) {
      throw new WebApplicationException(
          "Replacement warehouse capacity exceeds remaining capacity for location "
              + newWarehouse.location
              + ".",
          400);
    }
  }
}
