package com.fulfilment.application.monolith.fulfilment.domain.ports;

public interface StoreCatalog {

  boolean exists(Long storeId);
}
