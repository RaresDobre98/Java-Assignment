package com.fulfilment.application.monolith.fulfilment.adapters.database;

import com.fulfilment.application.monolith.fulfilment.domain.ports.StoreCatalog;
import com.fulfilment.application.monolith.stores.Store;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class StoreCatalogGateway implements StoreCatalog {

  @Override
  public boolean exists(Long storeId) {
    return storeId != null && Store.findById(storeId) != null;
  }
}
