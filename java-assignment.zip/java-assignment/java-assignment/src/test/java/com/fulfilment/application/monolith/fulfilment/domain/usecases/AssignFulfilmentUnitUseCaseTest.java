package com.fulfilment.application.monolith.fulfilment.domain.usecases;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fulfilment.application.monolith.fulfilment.domain.models.FulfilmentAssignment;
import com.fulfilment.application.monolith.fulfilment.domain.ports.FulfilmentAssignmentStore;
import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.ws.rs.WebApplicationException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

public class AssignFulfilmentUnitUseCaseTest {

  @Test
  public void shouldAssignWarehouseToProductAtStore() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001"));
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, warehouseStore);

    useCase.assign(assignment(1L, 1L, "MWH.001"));

    assertEquals(1, assignmentStore.assignments.size());
    assertEquals("MWH.001", assignmentStore.assignments.get(0).warehouseBusinessUnitCode);
  }

  @Test
  public void shouldRejectWhenProductAlreadyHasTwoWarehousesForSameStore() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    assignmentStore.assignments.add(assignment(1L, 1L, "MWH.001"));
    assignmentStore.assignments.add(assignment(1L, 1L, "MWH.002"));
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.003"));
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, warehouseStore);

    assertThrows(WebApplicationException.class, () -> useCase.assign(assignment(1L, 1L, "MWH.003")));
  }

  @Test
  public void shouldRejectWhenStoreAlreadyHasThreeWarehouses() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    assignmentStore.assignments.add(assignment(1L, 1L, "MWH.001"));
    assignmentStore.assignments.add(assignment(1L, 2L, "MWH.002"));
    assignmentStore.assignments.add(assignment(1L, 3L, "MWH.003"));
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.004"));
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, warehouseStore);

    assertThrows(WebApplicationException.class, () -> useCase.assign(assignment(1L, 4L, "MWH.004")));
  }

  @Test
  public void shouldRejectWhenWarehouseAlreadyStoresFiveProductTypes() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    assignmentStore.assignments.add(assignment(1L, 1L, "MWH.001"));
    assignmentStore.assignments.add(assignment(2L, 2L, "MWH.001"));
    assignmentStore.assignments.add(assignment(3L, 3L, "MWH.001"));
    assignmentStore.assignments.add(assignment(4L, 4L, "MWH.001"));
    assignmentStore.assignments.add(assignment(5L, 5L, "MWH.001"));
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001"));
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, warehouseStore);

    assertThrows(WebApplicationException.class, () -> useCase.assign(assignment(6L, 6L, "MWH.001")));
  }

  @Test
  public void shouldBeIdempotentWhenAssignmentAlreadyExists() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    assignmentStore.assignments.add(assignment(1L, 1L, "MWH.001"));
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001"));
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, warehouseStore);

    useCase.assign(assignment(1L, 1L, "MWH.001"));

    assertEquals(1, assignmentStore.assignments.size());
  }

  @Test
  public void shouldRejectUnknownWarehouse() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, new FakeWarehouseStore());

    assertThrows(WebApplicationException.class, () -> useCase.assign(assignment(1L, 1L, "MWH.404")));
  }


  @Test
  public void shouldAllowStoreWithThreeWarehousesWhenUsingAnAlreadyAssignedWarehouse() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    assignmentStore.assignments.add(assignment(1L, 1L, "MWH.001"));
    assignmentStore.assignments.add(assignment(1L, 2L, "MWH.002"));
    assignmentStore.assignments.add(assignment(1L, 3L, "MWH.003"));
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001"));
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, warehouseStore);

    useCase.assign(assignment(1L, 4L, "MWH.001"));

    assertEquals(4, assignmentStore.assignments.size());
  }

  @Test
  public void shouldAllowWarehouseWithFiveProductTypesWhenAssigningExistingProductType() {
    FakeAssignmentStore assignmentStore = new FakeAssignmentStore();
    assignmentStore.assignments.add(assignment(1L, 1L, "MWH.001"));
    assignmentStore.assignments.add(assignment(2L, 2L, "MWH.001"));
    assignmentStore.assignments.add(assignment(3L, 3L, "MWH.001"));
    assignmentStore.assignments.add(assignment(4L, 4L, "MWH.001"));
    assignmentStore.assignments.add(assignment(5L, 5L, "MWH.001"));
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001"));
    AssignFulfilmentUnitUseCase useCase =
        new AssignFulfilmentUnitUseCase(
            assignmentStore, storeId -> true, productId -> true, warehouseStore);

    useCase.assign(assignment(6L, 1L, "MWH.001"));

    assertEquals(6, assignmentStore.assignments.size());
  }

  private FulfilmentAssignment assignment(Long storeId, Long productId, String warehouseBusinessUnitCode) {
    var assignment = new FulfilmentAssignment();
    assignment.storeId = storeId;
    assignment.productId = productId;
    assignment.warehouseBusinessUnitCode = warehouseBusinessUnitCode;
    return assignment;
  }

  private Warehouse warehouse(String businessUnitCode) {
    var warehouse = new Warehouse();
    warehouse.businessUnitCode = businessUnitCode;
    return warehouse;
  }

  private static class FakeAssignmentStore implements FulfilmentAssignmentStore {
    private final List<FulfilmentAssignment> assignments = new ArrayList<>();

    @Override
    public List<FulfilmentAssignment> getAll() {
      return assignments;
    }

    @Override
    public void create(FulfilmentAssignment assignment) {
      assignments.add(assignment);
    }

    @Override
    public boolean exists(Long storeId, Long productId, String warehouseBusinessUnitCode) {
      return assignments.stream()
          .anyMatch(
              assignment ->
                  storeId.equals(assignment.storeId)
                      && productId.equals(assignment.productId)
                      && warehouseBusinessUnitCode.equals(assignment.warehouseBusinessUnitCode));
    }

    @Override
    public long countWarehousesForProductAtStore(Long storeId, Long productId) {
      return assignments.stream()
          .filter(assignment -> storeId.equals(assignment.storeId))
          .filter(assignment -> productId.equals(assignment.productId))
          .map(assignment -> assignment.warehouseBusinessUnitCode)
          .distinct()
          .count();
    }

    @Override
    public long countWarehousesForStore(Long storeId) {
      return assignments.stream()
          .filter(assignment -> storeId.equals(assignment.storeId))
          .map(assignment -> assignment.warehouseBusinessUnitCode)
          .distinct()
          .count();
    }

    @Override
    public long countProductsForWarehouse(String warehouseBusinessUnitCode) {
      return assignments.stream()
          .filter(assignment -> warehouseBusinessUnitCode.equals(assignment.warehouseBusinessUnitCode))
          .map(assignment -> assignment.productId)
          .distinct()
          .count();
    }
  }

  private static class FakeWarehouseStore implements WarehouseStore {
    private final List<Warehouse> warehouses = new ArrayList<>();

    @Override
    public List<Warehouse> getAll() {
      return warehouses;
    }

    @Override
    public void create(Warehouse warehouse) {
      warehouses.add(warehouse);
    }

    @Override
    public void update(Warehouse warehouse) {}

    @Override
    public void remove(Warehouse warehouse) {}

    @Override
    public Warehouse findByBusinessUnitCode(String buCode) {
      return warehouses.stream()
          .filter(warehouse -> buCode.equals(warehouse.businessUnitCode))
          .findFirst()
          .orElse(null);
    }
  }
}
