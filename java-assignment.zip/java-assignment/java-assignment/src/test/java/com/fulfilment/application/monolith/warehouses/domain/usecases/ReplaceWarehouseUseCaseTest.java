package com.fulfilment.application.monolith.warehouses.domain.usecases;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fulfilment.application.monolith.warehouses.domain.models.Location;
import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.ws.rs.WebApplicationException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

public class ReplaceWarehouseUseCaseTest {

  @Test
  public void shouldArchiveCurrentWarehouseAndCreateReplacement() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    Warehouse current = warehouse("MWH.001", "AMSTERDAM-001", 50, 10);
    warehouseStore.warehouses.add(current);
    ReplaceWarehouseUseCase useCase =
        new ReplaceWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 5, 100));

    useCase.replace(warehouse("MWH.001", "AMSTERDAM-002", 60, 10));

    assertNotNull(current.archivedAt);
    assertEquals(2, warehouseStore.warehouses.size());
    assertEquals("AMSTERDAM-002", warehouseStore.warehouses.get(1).location);
  }

  @Test
  public void shouldRejectReplacementWhenStockDoesNotMatch() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001", "AMSTERDAM-001", 50, 10));
    ReplaceWarehouseUseCase useCase =
        new ReplaceWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 5, 100));

    assertThrows(
        WebApplicationException.class,
        () -> useCase.replace(warehouse("MWH.001", "AMSTERDAM-002", 60, 9)));
  }

  @Test
  public void shouldRejectReplacementWhenCapacityCannotAccommodateCurrentStock() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001", "AMSTERDAM-001", 50, 10));
    ReplaceWarehouseUseCase useCase =
        new ReplaceWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 5, 100));

    assertThrows(
        WebApplicationException.class,
        () -> useCase.replace(warehouse("MWH.001", "AMSTERDAM-002", 5, 10)));
  }

  @Test
  public void shouldRejectReplacementForInvalidLocation() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001", "AMSTERDAM-001", 50, 10));
    ReplaceWarehouseUseCase useCase = new ReplaceWarehouseUseCase(warehouseStore, identifier -> null);

    assertThrows(
        WebApplicationException.class,
        () -> useCase.replace(warehouse("MWH.001", "UNKNOWN", 50, 10)));
  }

  private Warehouse warehouse(String businessUnitCode, String location, int capacity, int stock) {
    Warehouse warehouse = new Warehouse();
    warehouse.businessUnitCode = businessUnitCode;
    warehouse.location = location;
    warehouse.capacity = capacity;
    warehouse.stock = stock;
    return warehouse;
  }

  private static class FakeWarehouseStore implements WarehouseStore {
    private final List<Warehouse> warehouses = new ArrayList<>();

    @Override
    public List<Warehouse> getAll() {
      return warehouses.stream().filter(warehouse -> warehouse.archivedAt == null).toList();
    }

    @Override
    public void create(Warehouse warehouse) {
      warehouses.add(warehouse);
    }

    @Override
    public void update(Warehouse warehouse) {}

    @Override
    public void remove(Warehouse warehouse) {}

    @Override
    public Warehouse findByBusinessUnitCode(String buCode) {
      return warehouses.stream()
          .filter(warehouse -> warehouse.archivedAt == null)
          .filter(warehouse -> buCode.equals(warehouse.businessUnitCode))
          .findFirst()
          .orElse(null);
    }
  }
}
