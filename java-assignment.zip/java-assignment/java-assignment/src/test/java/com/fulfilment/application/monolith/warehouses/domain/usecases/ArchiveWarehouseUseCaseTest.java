package com.fulfilment.application.monolith.warehouses.domain.usecases;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.ws.rs.WebApplicationException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

public class ArchiveWarehouseUseCaseTest {

  @Test
  public void shouldArchiveExistingWarehouse() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    Warehouse warehouse = warehouse("MWH.001", "AMSTERDAM-001", 50, 10);
    warehouseStore.warehouses.add(warehouse);
    ArchiveWarehouseUseCase useCase = new ArchiveWarehouseUseCase(warehouseStore);

    useCase.archive(warehouse);

    assertNotNull(warehouse.archivedAt);
  }

  @Test
  public void shouldRejectUnknownWarehouse() {
    ArchiveWarehouseUseCase useCase = new ArchiveWarehouseUseCase(new FakeWarehouseStore());

    assertThrows(
        WebApplicationException.class,
        () -> useCase.archive(warehouse("MWH.404", "AMSTERDAM-001", 50, 10)));
  }

  private Warehouse warehouse(String businessUnitCode, String location, int capacity, int stock) {
    Warehouse warehouse = new Warehouse();
    warehouse.businessUnitCode = businessUnitCode;
    warehouse.location = location;
    warehouse.capacity = capacity;
    warehouse.stock = stock;
    return warehouse;
  }

  private static class FakeWarehouseStore implements WarehouseStore {
    private final List<Warehouse> warehouses = new ArrayList<>();

    @Override
    public List<Warehouse> getAll() {
      return warehouses;
    }

    @Override
    public void create(Warehouse warehouse) {
      warehouses.add(warehouse);
    }

    @Override
    public void update(Warehouse warehouse) {}

    @Override
    public void remove(Warehouse warehouse) {}

    @Override
    public Warehouse findByBusinessUnitCode(String buCode) {
      return warehouses.stream()
          .filter(warehouse -> buCode.equals(warehouse.businessUnitCode))
          .findFirst()
          .orElse(null);
    }
  }
}
