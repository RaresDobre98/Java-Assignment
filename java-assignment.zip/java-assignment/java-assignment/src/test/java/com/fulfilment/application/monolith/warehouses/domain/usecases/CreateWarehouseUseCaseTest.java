package com.fulfilment.application.monolith.warehouses.domain.usecases;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fulfilment.application.monolith.warehouses.domain.models.Location;
import com.fulfilment.application.monolith.warehouses.domain.models.Warehouse;
import com.fulfilment.application.monolith.warehouses.domain.ports.LocationResolver;
import com.fulfilment.application.monolith.warehouses.domain.ports.WarehouseStore;
import jakarta.ws.rs.WebApplicationException;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

public class CreateWarehouseUseCaseTest {

  @Test
  public void shouldCreateValidWarehouse() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    CreateWarehouseUseCase useCase =
        new CreateWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 2, 100));
    Warehouse warehouse = warehouse("MWH.100", "AMSTERDAM-001", 50, 10);

    useCase.create(warehouse);

    assertEquals(1, warehouseStore.warehouses.size());
    assertEquals("MWH.100", warehouseStore.warehouses.get(0).businessUnitCode);
  }

  @Test
  public void shouldRejectDuplicatedBusinessUnitCode() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.100", "AMSTERDAM-001", 50, 10));
    CreateWarehouseUseCase useCase =
        new CreateWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 2, 100));

    assertThrows(
        WebApplicationException.class,
        () -> useCase.create(warehouse("MWH.100", "AMSTERDAM-001", 50, 10)));
  }

  @Test
  public void shouldRejectWarehouseWithMoreStockThanCapacity() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    CreateWarehouseUseCase useCase =
        new CreateWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 2, 100));

    assertThrows(
        WebApplicationException.class,
        () -> useCase.create(warehouse("MWH.100", "AMSTERDAM-001", 50, 60)));
  }


  @Test
  public void shouldRejectInvalidLocation() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    CreateWarehouseUseCase useCase = new CreateWarehouseUseCase(warehouseStore, identifier -> null);

    assertThrows(
        WebApplicationException.class,
        () -> useCase.create(warehouse("MWH.101", "UNKNOWN", 50, 10)));
  }

  @Test
  public void shouldRejectWhenLocationReachedMaximumNumberOfWarehouses() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001", "ZWOLLE-001", 20, 10));
    CreateWarehouseUseCase useCase =
        new CreateWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 1, 100));

    assertThrows(
        WebApplicationException.class,
        () -> useCase.create(warehouse("MWH.102", "ZWOLLE-001", 20, 10)));
  }

  @Test
  public void shouldRejectWhenLocationCapacityWouldBeExceeded() {
    FakeWarehouseStore warehouseStore = new FakeWarehouseStore();
    warehouseStore.warehouses.add(warehouse("MWH.001", "AMSTERDAM-001", 60, 10));
    CreateWarehouseUseCase useCase =
        new CreateWarehouseUseCase(warehouseStore, identifier -> new Location(identifier, 2, 100));

    assertThrows(
        WebApplicationException.class,
        () -> useCase.create(warehouse("MWH.103", "AMSTERDAM-001", 50, 10)));
  }

  private Warehouse warehouse(String businessUnitCode, String location, int capacity, int stock) {
    Warehouse warehouse = new Warehouse();
    warehouse.businessUnitCode = businessUnitCode;
    warehouse.location = location;
    warehouse.capacity = capacity;
    warehouse.stock = stock;
    return warehouse;
  }

  private static class FakeWarehouseStore implements WarehouseStore {
    private final List<Warehouse> warehouses = new ArrayList<>();

    @Override
    public List<Warehouse> getAll() {
      return warehouses;
    }

    @Override
    public void create(Warehouse warehouse) {
      warehouses.add(warehouse);
    }

    @Override
    public void update(Warehouse warehouse) {}

    @Override
    public void remove(Warehouse warehouse) {}

    @Override
    public Warehouse findByBusinessUnitCode(String buCode) {
      return warehouses.stream()
          .filter(warehouse -> buCode.equals(warehouse.businessUnitCode))
          .findFirst()
          .orElse(null);
    }
  }
}
