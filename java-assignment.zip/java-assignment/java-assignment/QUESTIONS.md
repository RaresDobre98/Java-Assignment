# Questions

Here we have 3 questions related to the code base for you to answer. It is not about right or wrong, but more about what's the reasoning behind your decisions.

1. In this code base, we have some different implementation strategies when it comes to database access layer and manipulation. If you would maintain this code base, would you refactor any of those? Why?

**Answer:**
```txt
Yes. I would try to make the persistence approach consistent across the application.

Currently, Product uses a repository class, Store uses the active record style from PanacheEntity, and Warehouse uses a repository that implements a domain port. All of them work, but mixing styles makes the code harder to maintain because each module has a different way of querying, persisting and testing data access.

My preference would be to move toward the repository/port approach used by Warehouse, especially because it keeps the domain/use-case layer less coupled to the persistence implementation. This also makes the business rules easier to unit test, because the use cases depend on interfaces instead of static entity methods.

For small CRUD resources, the active record style can be convenient, but once business logic, integrations, transactions and validations grow, having repositories and use cases gives better separation of concerns.
```
----
2. When it comes to API spec and endpoints handlers, we have an Open API yaml file for the `Warehouse` API from which we generate code, but for the other endpoints - `Product` and `Store` - we just coded directly everything. What would be your thoughts about what are the pros and cons of each approach and what would be your choice?

**Answer:**
```txt
OpenAPI-first has the advantage of making the API contract explicit and stable. It is very useful when the API is consumed by other teams or external clients, because the contract can be reviewed, documented and used to generate clients/server interfaces. It also reduces the risk of the implementation drifting away from the agreed API.

The downside is that it adds build complexity and sometimes makes small changes slower, because the developer must update the specification and regenerate or adapt the generated code. It can also be less flexible if the generated interfaces are not ergonomic.

Code-first is faster and simpler for small internal endpoints. It is easy to implement and refactor, but the API contract may become less visible and documentation can become outdated if not generated from annotations or tests.

For this project, I would choose one consistent approach. If Warehouse is the most important public API, I would keep OpenAPI-first and eventually migrate Product and Store to the same style. If this is only an internal service, code-first with generated OpenAPI documentation from annotations could also be enough. The key point is consistency and having the API contract tested.
```
----
3. Given the need to balance thorough testing with time and resource constraints, how would you prioritize and implement tests for this project? Which types of tests would you focus on, and how would you ensure test coverage remains effective over time?

**Answer:**
```txt
I would prioritize tests around business rules and integration boundaries.

First, I would write fast unit tests for the Warehouse use cases, because most of the important rules are there: duplicate business unit code, invalid location, maximum number of warehouses per location, capacity limits, stock/capacity validation, archive behavior and replacement rules. These tests are cheap to run and make the business behavior clear.

Second, I would add endpoint/integration tests for the main happy paths and important error responses: create warehouse, reject invalid warehouse, archive warehouse, get archived warehouse returning 404, and replace warehouse. These tests verify that REST, transactions and persistence work together.

For Store, I would test the after-commit legacy synchronization behavior because that is an integration-sensitive requirement. Ideally, the legacy gateway would be behind an interface or mocked/spied in tests so we can verify it is called only after a successful commit and not when the transaction rolls back.

I would avoid trying to cover every trivial getter/setter or generated API class. Over time, I would keep coverage effective by focusing tests on business invariants, regression cases for bugs, and contract tests for public endpoints. I would also make the tests part of CI so failures are detected before merging changes.
```

----
Additional note about the bonus implementation:
```txt
For the bonus feature, I implemented the fulfilment association as a separate use case instead of embedding the rules directly into the Warehouse REST handler. The reason is that the relationship is not only a warehouse concern: it involves Store, Product and Warehouse together. Keeping it in a dedicated fulfilment use case makes the three constraints explicit and easier to unit test.

The API was added as a small code-first endpoint because the existing OpenAPI contract only described the Warehouse endpoints and the bonus did not provide a specific API contract. In a production code base, I would update the OpenAPI specification as well, so that this new endpoint is documented and client-generation friendly.
```
