# Case Study Scenarios to discuss

## Scenario 1: Cost Allocation and Tracking

**Situation**: The company needs to track and allocate costs accurately across different Warehouses and Stores. The costs include labor, inventory, transportation, and overhead expenses.

**Task**: Discuss the challenges in accurately tracking and allocating costs in a fulfillment environment. Think about what are important considerations for this, what are previous experiences that you have you could related to this problem and elaborate some questions and considerations

**Questions you may have and considerations:**

Accurate cost allocation in a fulfillment environment is challenging because costs are not always directly linked to a single Warehouse, Store, Product, or order. Some costs are direct, such as labor used in a specific warehouse or transportation for a specific store delivery, while others are shared, such as rent, utilities, platform costs, management overhead, or shared transportation routes.

A first important consideration would be to define the cost model clearly. For example, we should understand which costs are directly assigned and which costs need allocation rules. Transportation costs could be allocated by distance, number of deliveries, weight, volume, or order value. Labor costs could be allocated by worked hours, picked units, processed orders, or warehouse activity. Overhead costs could be allocated based on warehouse size, capacity usage, revenue contribution, or number of fulfilled orders.

Another challenge is data quality. Cost control is only useful if the operational data is reliable. If warehouse stock, fulfillment assignments, product dimensions, order volumes, or store mappings are incorrect, the allocated costs will also be incorrect. For this reason, I would want to understand the source of truth for each type of data and whether these sources are updated in real time, daily, weekly, or manually.

I would also consider the relationship between Warehouse, Store, Product, and Location. Since warehouses can fulfill products for stores, cost allocation may need to follow the actual fulfillment path, not just static ownership. For example, if Store A is fulfilled by Warehouse X for one product and Warehouse Y for another product, costs should reflect that operational reality.

Some questions I would ask are:

- What is the desired cost granularity: per Warehouse, per Store, per Product, per order, or per fulfillment assignment?
- Which costs are direct and which ones are shared?
- What allocation rules are currently used by finance, if any?
- Which system is the source of truth for labor, inventory, transportation, and overhead costs?
- How often does the business need cost reports: real time, daily, weekly, monthly?
- Should archived warehouses remain visible in cost reports?
- How should costs be handled when a warehouse is replaced but reuses the same Business Unit Code?
- Are historical cost reports expected to be immutable after financial closing?

From a technical perspective, I would avoid hardcoding allocation rules directly in business logic. Instead, I would model them explicitly so they can evolve as the business changes. I would also keep historical cost records immutable or versioned, especially for reporting and audit purposes.

## Scenario 2: Cost Optimization Strategies

**Situation**: The company wants to identify and implement cost optimization strategies for its fulfillment operations. The goal is to reduce overall costs without compromising service quality.

**Task**: Discuss potential cost optimization strategies for fulfillment operations and expected outcomes from that. How would you identify, prioritize and implement these strategies?

**Questions you may have and considerations:**

Cost optimization in fulfillment should not focus only on reducing expenses, because aggressive cost cutting can reduce service quality, increase delivery times, or create stock availability issues. I would approach it by identifying the main cost drivers and comparing them against service-level indicators such as delivery time, stock availability, order accuracy, and customer satisfaction.

Potential optimization areas include warehouse capacity usage, inventory placement, transportation routes, labor planning, stock levels, and fulfillment assignments between Stores, Products, and Warehouses. For example, if a Store is fulfilled by a distant Warehouse while a closer Warehouse has capacity and stock, transportation costs may be unnecessarily high. Similarly, if a Warehouse is underused but still has high fixed costs, the company may need to rebalance operations or consolidate fulfillment flows.

I would start by creating visibility. Before optimizing, the business needs dashboards or reports showing costs by Warehouse, Store, Product, and fulfillment route. Then I would identify outliers, such as warehouses with high cost per unit, stores with expensive fulfillment paths, products with high handling costs, or routes with low volume but high transportation cost.

Prioritization should be based on impact, feasibility, and risk. A good approach would be:

- quantify the cost saving opportunity;
- check operational impact;
- estimate implementation complexity;
- assess risks to service quality;
- implement gradually and measure results.

Examples of possible strategies:

- Reassign Stores or Products to closer or more efficient Warehouses.
- Optimize warehouse capacity usage to avoid underused facilities.
- Reduce split fulfillment, where one store/product demand is fulfilled by too many warehouses.
- Improve stock placement based on demand forecasts.
- Use batch transportation or route optimization to reduce delivery cost.
- Automate manual processes where labor cost is a significant driver.
- Define alerts when warehouse capacity, stock, or cost thresholds are exceeded.

Expected outcomes could include lower cost per fulfilled unit, reduced transportation cost, better warehouse utilization, fewer emergency stock movements, and more predictable operational budgets.

Some questions I would ask are:

- What are the current top cost drivers?
- Which costs are increasing faster than order volume?
- What service-level metrics must not be compromised?
- Are there contractual constraints with carriers, warehouses, or suppliers?
- How flexible are fulfillment assignments between Warehouses, Stores, and Products?
- Do we have enough historical data to compare before and after optimization?
- Are there seasonal patterns that affect cost and capacity?
- How will savings be measured and validated by finance?

From an implementation perspective, I would not introduce automated optimization immediately without business validation. I would first provide visibility, recommendations, simulations, and then controlled changes with monitoring.

## Scenario 3: Integration with Financial Systems

**Situation**: The Cost Control Tool needs to integrate with existing financial systems to ensure accurate and timely cost data. The integration should support real-time data synchronization and reporting.

**Task**: Discuss the importance of integrating the Cost Control Tool with financial systems. What benefits the company would have from that and how would you ensure seamless integration and data synchronization?

**Questions you may have and considerations:**

Integration with financial systems is important because operational cost data becomes much more valuable when it is aligned with official financial records. A fulfillment system may know operational facts, such as stock, warehouses, stores, products, and fulfillment assignments, but the financial system is usually the source of truth for actual costs, invoices, accounting periods, budgets, and financial reporting.

The main benefit of integration is that business users can compare operational performance with financial impact. For example, the company can understand not only how many orders a warehouse fulfilled, but also how much that operation actually cost, whether it stayed within budget, and how it compares to other warehouses or stores.

To ensure good integration, I would first clarify data ownership. Not every system should own every piece of data. For example, the fulfillment system may own warehouse operational status and fulfillment assignments, while the financial system may own actual posted costs, cost centers, budgets, and accounting periods. A clear contract is needed between systems.

For synchronization, I would prefer event-driven or asynchronous integration for most cases, especially when financial data does not need to block operational flows. For example, when a warehouse is created, archived, or replaced, the cost control/financial system could receive an event after the transaction is committed. For critical consistency, I would consider the transactional outbox pattern, because it avoids publishing events before the database commit and provides a reliable retry mechanism.

Important integration considerations include:

- consistent identifiers, such as Business Unit Code, Warehouse ID, Store ID, Product ID, and cost center;
- idempotency, so duplicate messages do not create duplicate financial records;
- retries and dead-letter handling for failed integrations;
- audit logs for financial traceability;
- reconciliation jobs to compare data between systems;
- versioning of integration contracts;
- clear handling of archived and replaced warehouses.

Some questions I would ask are:

- Which financial system is the source of truth for costs and budgets?
- What data must be synchronized in real time and what can be batch processed?
- Are Business Unit Codes mapped directly to financial cost centers?
- How are accounting periods and financial closing handled?
- What happens if the financial system is unavailable?
- Do we need exactly-once behavior, or is at-least-once with idempotency acceptable?
- How should corrections or backdated cost adjustments be handled?
- What audit requirements exist for cost changes?

The benefit of this integration is better financial visibility, fewer manual reconciliations, faster reporting, and more accurate cost control decisions. However, I would be careful not to couple operational transactions too tightly to the financial system availability. The fulfillment system should remain resilient even if the financial integration is temporarily delayed.

## Scenario 4: Budgeting and Forecasting

**Situation**: The company needs to develop budgeting and forecasting capabilities for its fulfillment operations. The goal is to predict future costs and allocate resources effectively.

**Task**: Discuss the importance of budgeting and forecasting in fulfillment operations and what would you take into account designing a system to support accurate budgeting and forecasting?

**Questions you may have and considerations:**

Budgeting and forecasting are important because fulfillment costs can change significantly depending on demand, seasonality, stock levels, transportation needs, labor availability, and warehouse capacity. Without forecasting, the business can either overspend by over-allocating resources or fail to meet demand because capacity and budget were underestimated.

A good forecasting system should combine historical cost data, operational data, and business assumptions. Historical cost data helps identify trends. Operational data explains the drivers behind those trends, such as order volume, warehouse utilization, number of products stored, number of stores fulfilled, and transportation distances. Business assumptions are also important, for example expected growth, planned warehouse replacements, new store openings, promotions, seasonal peaks, or supplier changes.

I would design the system so that budgets are not only static yearly numbers. The system should support budget versions, monthly or weekly forecasts, scenario planning, and variance analysis. For example, the business should be able to compare:

- planned budget;
- forecasted cost;
- actual cost;
- variance;
- explanation of variance.

Important dimensions for budgeting would include Warehouse, Store, Location, Product category, cost type, accounting period, and Business Unit Code. Since warehouse replacement is part of the domain, the system should also support historical continuity when a new warehouse reuses an old Business Unit Code, while still preserving the old warehouse's archived operational history.

Some questions I would ask are:

- What budgeting period is needed: monthly, quarterly, yearly?
- Should budgets be defined per Warehouse, Store, Product, Location, or cost center?
- What level of forecast accuracy is expected?
- How much historical data is available and how reliable is it?
- Are there strong seasonal patterns in demand or cost?
- Are planned business events available, such as new stores, new products, or warehouse replacements?
- Should the system support multiple forecast scenarios, such as optimistic, expected, and pessimistic?
- How should actuals be reconciled against forecasts?
- Who owns budget approval and forecast adjustments?

From a technical perspective, I would keep actual cost data separate from forecasts and budgets. Actuals should be immutable or auditable, while forecasts can be recalculated as new information arrives. I would also expose clear APIs and reports for variance analysis, because the business value comes not only from predicting costs, but also from understanding why actual costs differ from expectations.

## Scenario 5: Cost Control in Warehouse Replacement

**Situation**: The company is planning to replace an existing Warehouse with a new one. The new Warehouse will reuse the Business Unit Code of the old Warehouse. The old Warehouse will be archived, but its cost history must be preserved.

**Task**: Discuss the cost control aspects of replacing a Warehouse. Why is it important to preserve cost history and how this relates to keeping the new Warehouse operation within budget?

**Questions you may have and considerations:**

Preserving cost history during warehouse replacement is important because cost data is used for reporting, audit, budgeting, forecasting, and performance comparison. If the old warehouse's history is overwritten or lost, the company can no longer understand how the previous operation performed, what costs were associated with it, or whether the replacement improved the situation.

In this domain, the new Warehouse reuses the Business Unit Code of the old Warehouse, while the old Warehouse is archived. This means the Business Unit Code represents business continuity, but the system still needs to distinguish between the old operational instance and the new one. From a cost control perspective, this is important because historical costs should remain linked to the archived warehouse, while new costs should be linked to the new warehouse from the replacement date onward.

This allows the business to answer questions such as:

- How much did the old warehouse cost before replacement?
- Did the replacement reduce cost per fulfilled unit?
- Did transportation, labor, inventory, or overhead costs improve?
- Did the new warehouse stay within the budget planned for the replacement?
- Were there transition costs, duplicated operations, or temporary inefficiencies?
- How should costs be split during the transition period?

A key consideration is the effective date of replacement. The system should know exactly when the old warehouse stopped receiving new operational costs and when the new warehouse started accumulating costs. If there is a transition period where both warehouses operate in parallel, this should be represented explicitly.

I would also consider whether the Business Unit Code is used as a financial cost center. If yes, finance may want continuity under the same code, but operational reporting still needs the ability to separate old and new warehouse instances. Therefore, I would avoid using only the Business Unit Code as the unique historical identifier. The system should have an internal Warehouse ID or version/history model.

Some questions I would ask are:

- Is the Business Unit Code also used as a financial cost center?
- What is the effective replacement date?
- Can the old and new warehouses operate in parallel during transition?
- Should old warehouse costs remain visible in reports by default?
- How are one-time replacement costs tracked?
- Should budgets transfer fully to the new warehouse or be recalculated?
- Are there contractual, labor, or transportation costs that continue after archival?
- How should forecast accuracy be measured after replacement?
- Do we need approval workflows before replacing a warehouse?

From an implementation perspective, archiving instead of deleting is the correct approach because it preserves historical integrity. The replacement should create a new warehouse operational record while keeping the old one immutable or read-only for history. Cost reports should support both views: continuity by Business Unit Code and separation by warehouse version or archived warehouse identity.

This helps keep the new Warehouse operation within budget because the business can compare planned costs against actual new costs, identify whether the replacement achieved its financial goal, and avoid mixing old inefficiencies with new operational performance.

## Instructions for Candidates

Before starting the case study, read the BRIEFING.md to quickly understand the domain, entities, business rules, and other relevant details.

**Analyze the Scenarios**: Carefully analyze each scenario and consider the tasks provided. To make informed decisions about the project's scope and ensure valuable outcomes, what key information would you seek to gather before defining the boundaries of the work? Your goal is to bridge technical aspects with business value, bringing a high level discussion; no need to deep dive.